#include<iostream>
#include<stdlib.h>
using namespace std;
int main()
{
	int i,count=0;
	string data,even,odd;
	cin>>data;
	cout<<"The given data:"<<data<<endl;
	for(i=0;i<data.length();i++)
	{
		if(data[i]=='1')
			count++;
	}
	if(count%2==0)
		even=data+"0";
	else
		even=data+"1";
	if(count%2!=0)
		odd=data+"0";
	else
		odd=data+"1";
	cout<<"Even parity checking:"<<even<<endl;
	cout<<"Odd parity checking:"<<odd<<endl;
	return 0;
}